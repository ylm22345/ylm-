<?php
/*
 * @Author: your name
 * @Date: 2021-06-17 19:57:39
 * @LastEditTime: 2021-06-17 19:59:43
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \代码d:\phpstudy_pro\WWW\xm\php\list.php
 */
header('content-type:text/html;charset=utf8');
$link = mysqli_connect('localhost','root','root','sz2105');
$res = mysqli_query($link,"select * from miui");
$arr = [];
while($row = mysqli_fetch_assoc($res)){
    $arr[] = $row;
}
echo json_encode([
    "meta"=>[
        "status"=>0,
        "msg"=>"数据获取成功"
    ],
    "data"=>$arr
]);
