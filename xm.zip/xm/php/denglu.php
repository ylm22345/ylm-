
<?php
/*
 * @Author: your name
 * @Date: 2021-06-10 02:09:54
 * @LastEditTime: 2021-06-17 02:15:22
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \代码d:\phpstudy_pro\WWW\kuailegou\php\denglu.php
 */
// 获取数据

$username = $_GET['username'];
$password = $_GET['password'];
$remember = $_GET['remember'];

//  链接数据库
$link = mysqli_connect('127.0.0.1','root','root','sz2105');

$sql = "SELECT * FROM `users` WHERE `username`= '$username' ";
// 组织sql
$res = mysqli_query($link,$sql);
$row = mysqli_fetch_assoc($res);
if(!$row){
  $arr = ['status'=>0,"msg"=>"用户名不存在"];

  // echo json_encode($arr);// 用户名不存在
}else{
  if($row['password'] !== $password){
    $arr = ['status'=>0,"msg"=>"密码错误"];
    // echo json_encode($arr);// 密码错
    
  }else{
    $arr = ['status'=>1,"msg"=>"登录成功"];
    setCookie("username",$username);

  }
}
echo json_encode($arr);  

