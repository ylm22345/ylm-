<?php
header('content-type:text/html;charset=utf8');
$link = mysqli_connect('localhost','root','root','project');
