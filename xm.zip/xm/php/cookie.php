<?php
/*
 * @Author: your name
 * @Date: 2021-05-25 17:40:19
 * @LastEditTime: 2021-06-16 20:55:40
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \代码\阶段二.2\02-代码\08-login\login.php
 */

// 接受数据
$username = $_POST['username'];
$password = $_POST['password'];

// 连接数据库
$link = mysqli_connect('127.0.0.1','root','root',"sz2105");
if(!$link){
  echo "数据库连接失败<br>";
  echo mysqli_connect_error($link);
  die; // die之后所有php代码都不执行
}
// 组织sql查询用户名 并执行
$sql = " SELECT * FROM `users` WHERE `name`='$username'";
$res = mysqli_query($link,$sql);
// 解析结果并判断
$row = mysqli_fetch_assoc($res);
if(!$row){
  echo "用户名输出入错误";
  header("location: ../html/enter.html");
  die;
}

// 代码执行到此处，则用户名存在，验证密码
if($password !== $row['password']){
  echo "密码输出入错误";
  header("location: ../html/enter.html");
  die;
}

// 代码执行到此处，则登录成功，跳转并将用户信息，写入cookie
setcookie("username",$username);

