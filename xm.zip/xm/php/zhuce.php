<?php
/*
 * @Author: your name
 * @Date: 2021-06-09 13:52:12
 * @LastEditTime: 2021-06-10 02:04:32
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \代码d:\phpstudy_pro\WWW\kuailegou\php\zhuce.php
 */
// 接受注册用户名数据
$username = isset($_GET['username'])?$_GET['username']:'';
$password = isset($_GET['password'])?$_GET['password']:'';
// 链接数据库
$link = mysqli_connect('127.0.0.1','root','root','sz2105');

  $sql = "SELECT * FROM `users` WHERE `username`= '$username' ";
  // echo $sql;
  // 组织sql
  $res = mysqli_query($link,$sql);
  $row = mysqli_fetch_assoc($res);

  if($row){
    echo '0';
  }
 else if($password){

       $sql = "INSERT INTO `users`(`username`,`password`) VALUE('$username','$password') ";
        $res = mysqli_query($link,$sql);
        if($res){
            echo '1';
          }else{
            echo "0";
          }
    }
   
  
  
  
   

  // 组织写入数据库的sql
 
  










