<?php
/*
 * @Author: your name
 * @Date: 2021-06-17 21:05:04
 * @LastEditTime: 2021-06-17 21:06:55
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \代码d:\phpstudy_pro\WWW\xm\php\cart.php
 */
header('content-type:text/html;charset=utf8');
$link = mysqli_connect('localhost','root','root','sz2105');
$ids = $_GET["ids"];
$res = mysqli_query($link,"select * from scenics where id in($ids)");
$arr = [];
while($row = mysqli_fetch_assoc($res)){
    $arr[] = $row;
}
echo json_encode([
    "meta"=>[
        "status"=>1,
        "msg"=>"数据获取成功"
    ],
    "data"=>$arr
]);