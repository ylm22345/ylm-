/*
 * @Author: your name
 * @Date: 2021-06-17 16:05:04
 * @LastEditTime: 2021-06-17 21:55:28
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \代码d:\phpstudy_pro\WWW\xm\js\list.js
 */

//获取数据
$(function() {
    var loadindex = layer.load(1, {
        shade: [0.5, '#333']
    })
    $.ajax({
        url: './php/list.php',
        dataType: 'json',
        success(res) {
            var {
                data
            } = res;
            console.log(data);
          //   data.reverse()
            var pageSize = 4;
            new Page("page", {
                language: {
                    first: '首页',
                    prev: '上一页',
                    next: '下一页',
                    last: '尾页'
                },
                pageData: {
                    pageSize,
                    total: data.length
                },
                show: function(currentPage) {
                    var tmp = data.slice((currentPage - 1) * pageSize, currentPage * pageSize)
                    var html = '';
                    tmp.forEach(v => {
                        html += `
                    <div class="bbigbox">
                        <div class="details-l">
                            <img src="./images/tt1.png" alt="">
                            <div class="zhe"></div>
                        </div>
                        <div class="fdj">
                                <img src="${v.imgpath}" alt="">
                        </div>
                        <div class="details-r">
                            <p>${v.name}</p>
                            <p>$${v.price}</p>
                            <div>
                            ${v.introduce}
                            </div>
                            <button class="de-btn">
                                加入购物车
                            </button>
                        </div>
                    </div>
                        `
                    })
                    $('.details').html(html)
                }
            })
            layer.close(loadindex)
        }
    })
  })

