/*
 * @Author: your name
 * @Date: 2021-06-17 02:00:41
 * @LastEditTime: 2021-06-17 02:00:41
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \代码d:\phpstudy_pro\WWW\xm\js\enter.js
 */
/*
 * @Author: your name
 * @Date: 2021-06-16 14:40:14
 * @LastEditTime: 2021-06-16 17:43:27
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \代码d:\phpstudy_pro\WWW\xm\js\enter.js
 */
var rememberusername = getCookie('rememberusername');
var user = document.querySelector("[name='username']")

if(rememberusername){
    user.value = rememberusername;
}
console.log(jQuery('.loginForm'));
jQuery('.loginForm').validate({
    rules:{
        username:'required',
        password:'required'
    },
    messages:{
        username:'用户名不能为空',
        password:'密码不能为空'
    },
    submitHandler:function(form){
        console.log(222)
        var loadindex = layer.load(1, {
            shade: [0.5,'#333'] //0.1透明度的白色背景
        });
        jQuery('.btn1').prop('disabled',true)
        jQuery.ajax({
            url:'../php/enter.php',
            data:jQuery(form).serialize(),
            dataType:'json',
            method:'post',
            success:res=>{
                // 解构赋值
                var {meta:{status,msg}} = res;                
                layer.close(loadindex)
                var msgindex = layer.msg(msg)
                if(status===0){
                    // 设置cookie
                    setCookie('username',jQuery('[name="username"]').val())
                    if(jQuery("[name='remember']").prop('checked')){
                        setCookie('rememberusername',jQuery('[name="username"]').val(),7*24*3600)
                    }
                    // 应该跳转
                    setTimeout(()=>{
                        layer.close(msgindex)
                        jQuery('.btn1').prop('disabled',false)
                        var url = localStorage.getItem('url')
                        if(!url){
                            location.href = '../MIUI.html';
                        }else{
                            localStorage.removeItem('url')
                            location.href = url
                        }
                        
                    },2000)
                    
                }else{
                    jQuery('.btn1').prop('disabled',false)
                    return false;
                }
            }
        })
        return false;
    }
})