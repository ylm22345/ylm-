/*
 * @Author: your name
 * @Date: 2021-06-17 20:42:45
 * @LastEditTime: 2021-06-17 20:54:55
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \代码d:\phpstudy_pro\WWW\xm\js\fangdajin.js
 */
// 放大镜
setTimeout(function(){
    var obox1=document.querySelector(".details-l")
var ozhe=document.querySelector(".zhe")
var oimg2=document.querySelector(".fdj>img")
var obox2=document.querySelector(".fdj")

var moveX
var moveY
obox1.addEventListener("mousemove",function(e){
    e=e||window.event
    moveX=e.pageX-obox1.offsetLeft-300
    moveY=e.pageY-obox1.offsetTop-220

    if (moveX<=0) {
        moveX=0
    }
    else if (moveX>=150){
        moveX=150
    }
    if (moveY<=0) {
        moveY=0
    }
    else if (moveY>=150){
        moveY=150
    }
    ozhe.style.left=moveX+"px"
    ozhe.style.top=moveY+"px"

    oimg2.style.left=(-moveX*1.6)+"px"
    oimg2.style.top=(-moveY*1.6)+"px"
    
})
obox1.addEventListener("mouseover",function(){
    ozhe.style.display="block"
    obox2.style.display="block"
})
obox1.addEventListener("mouseout",function(){
    ozhe.style.display="none"
    obox2.style.display="none"
})},150)
