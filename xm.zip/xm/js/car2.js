/*
 * @Author: your name
 * @Date: 2021-06-18 10:17:50
 * @LastEditTime: 2021-06-18 20:24:05
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \代码d:\phpstudy_pro\WWW\xm\js\car2.js
 */

//全选功能
var xuans=document.querySelectorAll('.danxuan')
var bot=document.querySelector(".car-bottom")
select()
function select(){
    $('[name="quanxuan"]').click(function(){
        $('[name="danxuan"]').prop('checked',$(this).prop('checked'))
        $('[name="quanxuan"]').prop('checked',$(this).prop('checked'))
    })
    $('[name="danxuan"]').click(function(){
        var selectArr = Array.prototype.slice.call($('[name="danxuan"]'))
        var selectStatus = selectArr.every(v=>v.checked)
        $('[name="quanxuan"]').prop('checked',selectStatus)
    })
}
// 数量加减
jiajian()
function jiajian(){
    var num=0
    $('.sdown').click(function(){
        if(num>=1){console.log("======");
        num--
        $(this).next().text(num) 
        //计算小计
        var xprice=num*($(this).parent().siblings().find('.price').text())
        $(this).parent().siblings().find('.subtotal').text(xprice)
        totalXuan()
        }
    })
    $('.sup').click(function(){
        if(num<10){console.log("+++++++++");
            num++
        $(this).prev().text(num) 
        //计算小计
        var xprice=num*($(this).parent().siblings().find('.price').text())
        $(this).parent().siblings().find('.subtotal').text(xprice)
        totalXuan()
        }
    })
}

var aLenght=Object.keys(Array.prototype.slice.call(xuans)).length;

function totalXuan(){
    var sum=0//商品总计
    //遍历每一个选中框对象
    for(var i=0;i<aLenght;i++){
        //判断当前选中框是否被选中
        if(xuans[i].checked){
            //获取当前被选中的商品小计
            console.log("----------");
            var num=xuans[i].parentNode.parentNode.children[3].lastElementChild.innerHTML
            sum+=parseFloat(num)
            
        }
    }
    //给已选商品总计赋值
    bot.lastElementChild.lastElementChild.innerHTML=sum
    // console.log(bot);
}
totalXuan()





